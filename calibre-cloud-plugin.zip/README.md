# calibre-cloud-plugin
Calibre plugin for cloud strorages
